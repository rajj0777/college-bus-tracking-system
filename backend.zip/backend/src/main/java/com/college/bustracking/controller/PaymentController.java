package com.college.bustracking.controller;

import com.college.bustracking.dto.BusTrackingDTOs.*;
import com.college.bustracking.service.PaymentService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/payments")
@RequiredArgsConstructor
public class PaymentController {

    private final PaymentService paymentService;

    /**
     * POST /api/payments/create-order
     * Access: STUDENT only
     *
     * Step 1 of payment flow.
     * Student calls this before applying for a pass.
     * Returns Razorpay orderId + keyId which frontend uses to open payment modal.
     *
     * Example request:
     * {
     *   "amount": 500.00,
     *   "receipt": "pass-student-1-route-2"
     * }
     */
    @PostMapping("/create-order")
    @PreAuthorize("hasRole('STUDENT')")
    public ResponseEntity<ApiResponse<PaymentOrderResponse>> createOrder(
            @Valid @RequestBody PaymentOrderRequest request) {
        PaymentOrderResponse response = paymentService.createOrder(request);
        return ResponseEntity.ok(ApiResponse.success(
                "Razorpay order created. Proceed to payment.", response));
    }

    /**
     * POST /api/payments/verify
     * Access: STUDENT only
     *
     * Optional standalone Step 2 — verify payment signature without applying pass.
     * Useful if you want to verify payment separately before a different action.
     *
     * For bus pass applications, verification is done automatically inside
     * POST /api/passes — you don't need to call this separately.
     *
     * Example request:
     * {
     *   "razorpayOrderId": "order_xxxx",
     *   "razorpayPaymentId": "pay_xxxx",
     *   "razorpaySignature": "abc123..."
     * }
     */
    @PostMapping("/verify")
    @PreAuthorize("hasRole('STUDENT')")
    public ResponseEntity<ApiResponse<PaymentVerifyResponse>> verifyPayment(
            @Valid @RequestBody PaymentVerifyRequest request) {
        PaymentVerifyResponse response = paymentService.verifyPayment(request);
        return ResponseEntity.ok(ApiResponse.success(
                response.isVerified() ? "Payment verified" : "Payment verification failed",
                response));
    }
}
