package com.college.bustracking.service;

import com.college.bustracking.dto.BusTrackingDTOs.*;
import com.college.bustracking.exception.DuplicateResourceException;
import com.college.bustracking.exception.ResourceNotFoundException;
import com.college.bustracking.model.Bus;
import com.college.bustracking.model.Route;
import com.college.bustracking.repository.BusRepository;
import com.college.bustracking.repository.RouteRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class RouteService {

    private final RouteRepository routeRepository;
    private final BusRepository busRepository;
    private final BusService busService;

    public List<RouteResponse> getAllRoutes() {
        return routeRepository.findAll().stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    public List<RouteResponse> getActiveRoutes() {
        return routeRepository.findByIsActive(true).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    public RouteResponse getRouteById(Long id) {
        Route route = routeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Route", "id", id));
        return mapToResponse(route);
    }

    public RouteResponse createRoute(RouteRequest request) {
        if (routeRepository.existsByRouteNumber(request.getRouteNumber())) {
            throw new DuplicateResourceException("Route already exists with number: " + request.getRouteNumber());
        }

        Bus bus = null;
        if (request.getBusId() != null) {
            bus = busRepository.findById(request.getBusId())
                    .orElseThrow(() -> new ResourceNotFoundException("Bus", "id", request.getBusId()));
        }

        Route route = Route.builder()
                .routeName(request.getRouteName())
                .routeNumber(request.getRouteNumber())
                .startPoint(request.getStartPoint())
                .startLatitude(request.getStartLatitude())
                .startLongitude(request.getStartLongitude())
                .endPoint(request.getEndPoint())
                .endLatitude(request.getEndLatitude())
                .endLongitude(request.getEndLongitude())
                .departureTime(request.getDepartureTime())
                .returnTime(request.getReturnTime())
                .totalDistanceKm(request.getTotalDistanceKm())
                .stops(request.getStops())
                .stopsCoordinates(request.getStopsCoordinates())
                .monthlyFee(request.getMonthlyFee())
                .bus(bus)
                .isActive(true)
                .build();

        return mapToResponse(routeRepository.save(route));
    }

    public RouteResponse updateRoute(Long id, RouteRequest request) {
        Route route = routeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Route", "id", id));

        Bus bus = null;
        if (request.getBusId() != null) {
            bus = busRepository.findById(request.getBusId())
                    .orElseThrow(() -> new ResourceNotFoundException("Bus", "id", request.getBusId()));
        }

        route.setRouteName(request.getRouteName());
        route.setStartPoint(request.getStartPoint());
        route.setStartLatitude(request.getStartLatitude());
        route.setStartLongitude(request.getStartLongitude());
        route.setEndPoint(request.getEndPoint());
        route.setEndLatitude(request.getEndLatitude());
        route.setEndLongitude(request.getEndLongitude());
        route.setDepartureTime(request.getDepartureTime());
        route.setReturnTime(request.getReturnTime());
        route.setTotalDistanceKm(request.getTotalDistanceKm());
        route.setStops(request.getStops());
        route.setStopsCoordinates(request.getStopsCoordinates());
        route.setMonthlyFee(request.getMonthlyFee());
        route.setBus(bus);

        return mapToResponse(routeRepository.save(route));
    }

    public void deleteRoute(Long id) {
        if (!routeRepository.existsById(id)) {
            throw new ResourceNotFoundException("Route", "id", id);
        }
        routeRepository.deleteById(id);
    }

    public RouteResponse mapToResponse(Route route) {
        BusResponse busResponse = null;
        if (route.getBus() != null) {
            busResponse = busService.mapToResponse(route.getBus());
        }

        return RouteResponse.builder()
                .id(route.getId())
                .routeName(route.getRouteName())
                .routeNumber(route.getRouteNumber())
                .startPoint(route.getStartPoint())
                .startLatitude(route.getStartLatitude())
                .startLongitude(route.getStartLongitude())
                .endPoint(route.getEndPoint())
                .endLatitude(route.getEndLatitude())
                .endLongitude(route.getEndLongitude())
                .departureTime(route.getDepartureTime())
                .returnTime(route.getReturnTime())
                .totalDistanceKm(route.getTotalDistanceKm())
                .stops(route.getStops())
                .stopsCoordinates(route.getStopsCoordinates())
                .monthlyFee(route.getMonthlyFee())
                .isActive(route.getIsActive())
                .bus(busResponse)
                .build();
    }
}
