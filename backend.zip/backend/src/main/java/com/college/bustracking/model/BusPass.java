package com.college.bustracking.model;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "bus_passes")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BusPass {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "pass_number", unique = true, nullable = false)
    private String passNumber;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "student_id", nullable = false)
    private User student;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "route_id", nullable = false)
    private Route route;

    @Column(name = "valid_from", nullable = false)
    private LocalDate validFrom;

    @Column(name = "valid_to", nullable = false)
    private LocalDate validTo;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private PassStatus status = PassStatus.PENDING;

    @Column(name = "amount_paid")
    private Double amountPaid;

    // ── Razorpay fields ──────────────────────────────────────
    // Razorpay order ID created via /api/payments/create-order
    @Column(name = "razorpay_order_id")
    private String razorpayOrderId;

    // Razorpay payment ID received after successful payment on frontend
    @Column(name = "razorpay_payment_id")
    private String razorpayPaymentId;

    // Razorpay signature received from frontend — verified server-side
    @Column(name = "razorpay_signature")
    private String razorpaySignature;

    // Payment verification status: PENDING | SUCCESS | FAILED
    @Column(name = "payment_status")
    private String paymentStatus = "PENDING";
    // ─────────────────────────────────────────────────────────

    // Kept for backward-compatibility (manual reference or notes)
    @Column(name = "payment_reference")
    private String paymentReference;

    @Column(name = "remarks", columnDefinition = "TEXT")
    private String remarks;

    @Column(name = "boarding_stop")
    private String boardingStop;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    public enum PassStatus {
        PENDING, ACTIVE, EXPIRED, REJECTED, CANCELLED
    }
}
