package com.college.bustracking.config;

import com.college.bustracking.model.User;
import com.college.bustracking.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

/**
 * Extracted into its own @Service to break the circular dependency:
 * JwtAuthenticationFilter → UserDetailsService → SecurityConfig → JwtAuthenticationFilter
 *
 * Now the chain is:
 * JwtAuthenticationFilter → UserDetailsServiceImpl  (no cycle)
 * SecurityConfig          → UserDetailsServiceImpl  (no cycle)
 */
@Service
@RequiredArgsConstructor
public class UserDetailsServiceImpl implements UserDetailsService {

    private final UserRepository userRepository;

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new UsernameNotFoundException("User not found: " + email));

        return org.springframework.security.core.userdetails.User.builder()
                .username(user.getEmail())
                .password(user.getPassword())
                .roles(user.getRole().name())
                .build();
    }
}
