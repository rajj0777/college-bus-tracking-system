package com.college.bustracking.service;

import com.college.bustracking.dto.BusTrackingDTOs.*;
import com.college.bustracking.exception.DuplicateResourceException;
import com.college.bustracking.exception.ResourceNotFoundException;
import com.college.bustracking.model.Bus;
import com.college.bustracking.repository.BusRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class BusService {

    private final BusRepository busRepository;

    public List<BusResponse> getAllBuses() {
        return busRepository.findAll().stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    public BusResponse getBusById(Long id) {
        Bus bus = busRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Bus", "id", id));
        return mapToResponse(bus);
    }

    public List<BusResponse> getActiveBuses() {
        return busRepository.findByStatus(Bus.BusStatus.ACTIVE).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    public BusResponse createBus(BusRequest request) {
        if (busRepository.existsByBusNumber(request.getBusNumber())) {
            throw new DuplicateResourceException("Bus already exists with number: " + request.getBusNumber());
        }

        Bus bus = Bus.builder()
                .busNumber(request.getBusNumber())
                .driverName(request.getDriverName())
                .driverPhone(request.getDriverPhone())
                .capacity(request.getCapacity())
                .status(request.getStatus() != null
                        ? Bus.BusStatus.valueOf(request.getStatus())
                        : Bus.BusStatus.ACTIVE)
                .build();

        return mapToResponse(busRepository.save(bus));
    }

    public BusResponse updateBus(Long id, BusRequest request) {
        Bus bus = busRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Bus", "id", id));

        if (!bus.getBusNumber().equals(request.getBusNumber()) &&
                busRepository.existsByBusNumber(request.getBusNumber())) {
            throw new DuplicateResourceException("Bus number already in use: " + request.getBusNumber());
        }

        bus.setBusNumber(request.getBusNumber());
        bus.setDriverName(request.getDriverName());
        bus.setDriverPhone(request.getDriverPhone());
        bus.setCapacity(request.getCapacity());
        if (request.getStatus() != null) {
            bus.setStatus(Bus.BusStatus.valueOf(request.getStatus()));
        }

        return mapToResponse(busRepository.save(bus));
    }

    public void deleteBus(Long id) {
        if (!busRepository.existsById(id)) {
            throw new ResourceNotFoundException("Bus", "id", id);
        }
        busRepository.deleteById(id);
    }

    @Transactional
    public BusResponse updateBusLocation(Long busId, LocationUpdateRequest request) {
        if (!busRepository.existsById(busId)) {
            throw new ResourceNotFoundException("Bus", "id", busId);
        }
        busRepository.updateBusLocation(
                busId,
                request.getLatitude(),
                request.getLongitude(),
                request.getLocationName(),
                LocalDateTime.now()
        );
        return getBusById(busId);
    }

    public BusResponse mapToResponse(Bus bus) {
        return BusResponse.builder()
                .id(bus.getId())
                .busNumber(bus.getBusNumber())
                .driverName(bus.getDriverName())
                .driverPhone(bus.getDriverPhone())
                .capacity(bus.getCapacity())
                .status(bus.getStatus().name())
                .currentLatitude(bus.getCurrentLatitude())
                .currentLongitude(bus.getCurrentLongitude())
                .currentLocationName(bus.getCurrentLocationName())
                .lastLocationUpdate(bus.getLastLocationUpdate())
                .build();
    }
}
