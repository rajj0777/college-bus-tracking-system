package com.college.bustracking.repository;

import com.college.bustracking.model.Route;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface RouteRepository extends JpaRepository<Route, Long> {

    Optional<Route> findByRouteNumber(String routeNumber);

    Boolean existsByRouteNumber(String routeNumber);

    List<Route> findByIsActive(Boolean isActive);

    List<Route> findByBusId(Long busId);
}
