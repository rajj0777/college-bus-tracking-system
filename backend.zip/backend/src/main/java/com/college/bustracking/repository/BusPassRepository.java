package com.college.bustracking.repository;

import com.college.bustracking.model.BusPass;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface BusPassRepository extends JpaRepository<BusPass, Long> {

    List<BusPass> findByStudentId(Long studentId);

    List<BusPass> findByStatus(BusPass.PassStatus status);

    Optional<BusPass> findByStudentIdAndStatus(Long studentId, BusPass.PassStatus status);

    List<BusPass> findByRouteId(Long routeId);

    Optional<BusPass> findByPassNumber(String passNumber);

    Boolean existsByPassNumber(String passNumber);

    Long countByStatus(BusPass.PassStatus status);

    @Query("SELECT bp FROM BusPass bp WHERE bp.student.id = :studentId ORDER BY bp.createdAt DESC")
    List<BusPass> findByStudentIdOrderByCreatedAtDesc(@Param("studentId") Long studentId);
}
