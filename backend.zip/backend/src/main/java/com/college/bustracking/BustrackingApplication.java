package com.college.bustracking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BustrackingApplication {

	public static void main(String[] args) {
		SpringApplication.run(BustrackingApplication.class, args);
		System.out.println("====================================================");
		System.out.println("  College Bus Tracking System is running!");
		System.out.println("  API Base URL: http://localhost:8080/api");
		System.out.println("====================================================");
	}

}
