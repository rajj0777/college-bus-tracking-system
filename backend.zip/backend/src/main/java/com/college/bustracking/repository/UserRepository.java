package com.college.bustracking.repository;

import com.college.bustracking.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    Optional<User> findByEmail(String email);

    Optional<User> findByEmailAndIsActive(String email, Boolean isActive);

    List<User> findByRole(User.Role role);

    Boolean existsByEmail(String email);

    @Query("SELECT u FROM User u WHERE u.department = :dept AND u.role = 'STUDENT'")
    List<User> findStudentsByDepartment(@Param("dept") String department);
}
