package com.college.bustracking.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

@Entity
@Table(name = "routes")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Route {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    @Column(name = "route_name", nullable = false)
    private String routeName;

    @NotBlank
    @Column(name = "route_number", unique = true, nullable = false)
    private String routeNumber;

    @Column(name = "start_point", nullable = false)
    private String startPoint;

    // Google Maps coordinates for start point
    @Column(name = "start_latitude")
    private Double startLatitude;

    @Column(name = "start_longitude")
    private Double startLongitude;

    @Column(name = "end_point", nullable = false)
    private String endPoint;

    // Google Maps coordinates for end point
    @Column(name = "end_latitude")
    private Double endLatitude;

    @Column(name = "end_longitude")
    private Double endLongitude;

    @Column(name = "departure_time")
    private LocalTime departureTime;

    @Column(name = "return_time")
    private LocalTime returnTime;

    @Column(name = "total_distance_km")
    private Double totalDistanceKm;

    // Comma-separated stop names
    @Column(name = "stops", columnDefinition = "TEXT")
    private String stops;

    // JSON array of stop coordinates: [{"name":"Stop A","lat":12.97,"lng":77.59}, ...]
    // Stored as TEXT; parsed by frontend to render on Google Maps
    @Column(name = "stops_coordinates", columnDefinition = "TEXT")
    private String stopsCoordinates;

    @Column(name = "monthly_fee")
    private Double monthlyFee;

    @Column(name = "is_active")
    private Boolean isActive = true;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "bus_id")
    private Bus bus;

    @OneToMany(mappedBy = "route", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<BusPass> busPasses;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
}
