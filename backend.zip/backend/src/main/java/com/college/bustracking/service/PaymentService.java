package com.college.bustracking.service;

import com.college.bustracking.dto.BusTrackingDTOs.*;
import com.college.bustracking.exception.BusinessException;
import com.razorpay.Order;
import com.razorpay.RazorpayClient;
import com.razorpay.RazorpayException;
import com.razorpay.Utils;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class PaymentService {

    @Value("${razorpay.key.id}")
    private String keyId;

    @Value("${razorpay.key.secret}")
    private String keySecret;

    /**
     * Creates a Razorpay order.
     * amount is expected in INR; Razorpay requires paise (multiply by 100).
     *
     * Flow:
     *  1. Student clicks "Pay Now" on frontend
     *  2. Frontend calls POST /api/payments/create-order with amount
     *  3. Backend creates Razorpay order and returns orderId + keyId
     *  4. Frontend opens Razorpay payment modal using returned data
     *  5. On success, Razorpay returns paymentId + signature to frontend
     *  6. Frontend calls POST /api/payments/verify  (optional standalone verify)
     *     OR directly calls POST /api/passes with all three IDs for combined verify+apply
     */
    public PaymentOrderResponse createOrder(PaymentOrderRequest request) {
        try {
            RazorpayClient client = new RazorpayClient(keyId, keySecret);

            JSONObject orderRequest = new JSONObject();
            // Convert INR to paise (Razorpay works in smallest currency unit)
            int amountInPaise = (int) (request.getAmount() * 100);
            orderRequest.put("amount", amountInPaise);
            orderRequest.put("currency", "INR");
            orderRequest.put("receipt", request.getReceipt() != null
                    ? request.getReceipt()
                    : "receipt_" + System.currentTimeMillis());
            orderRequest.put("payment_capture", 1); // auto-capture payment

            Order order = client.orders.create(orderRequest);
            log.info("Razorpay order created: {}", order.get("id").toString());

            return PaymentOrderResponse.builder()
                    .orderId(order.get("id").toString())
                    .amount(request.getAmount())
                    .currency("INR")
                    .keyId(keyId)   // safe to return — needed by frontend Razorpay SDK
                    .receipt(order.get("receipt").toString())
                    .build();

        } catch (RazorpayException e) {
            log.error("Failed to create Razorpay order: {}", e.getMessage());
            throw new BusinessException("Payment order creation failed: " + e.getMessage());
        }
    }

    /**
     * Verifies the Razorpay payment signature.
     *
     * Razorpay signs the response as:
     *   HMAC-SHA256(orderId + "|" + paymentId, keySecret)
     *
     * This must be verified server-side — never trust the frontend alone.
     */
    public PaymentVerifyResponse verifyPayment(PaymentVerifyRequest request) {
        try {
            JSONObject attributes = new JSONObject();
            attributes.put("razorpay_order_id", request.getRazorpayOrderId());
            attributes.put("razorpay_payment_id", request.getRazorpayPaymentId());
            attributes.put("razorpay_signature", request.getRazorpaySignature());

            Utils.verifyPaymentSignature(attributes, keySecret);
            log.info("Payment signature verified for order: {}", request.getRazorpayOrderId());

            return PaymentVerifyResponse.builder()
                    .verified(true)
                    .message("Payment verified successfully")
                    .build();

        } catch (RazorpayException e) {
            log.warn("Payment signature verification failed: {}", e.getMessage());
            return PaymentVerifyResponse.builder()
                    .verified(false)
                    .message("Payment verification failed: " + e.getMessage())
                    .build();
        }
    }

    /**
     * Convenience method used by BusPassService to verify payment inline
     * during pass application. Throws BusinessException if invalid.
     */
    public void verifyAndAssert(String orderId, String paymentId, String signature) {
        PaymentVerifyRequest req = new PaymentVerifyRequest(orderId, paymentId, signature);
        PaymentVerifyResponse result = verifyPayment(req);
        if (!result.isVerified()) {
            throw new BusinessException("Payment verification failed. Please complete payment before applying for a pass.");
        }
    }
}
