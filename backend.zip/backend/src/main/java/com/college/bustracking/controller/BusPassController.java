package com.college.bustracking.controller;

import com.college.bustracking.dto.BusTrackingDTOs.*;
import com.college.bustracking.repository.UserRepository;
import com.college.bustracking.service.BusPassService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/passes")
@RequiredArgsConstructor
public class BusPassController {

    private final BusPassService busPassService;
    private final UserRepository userRepository;

    private Long getCurrentUserId(Authentication authentication) {
        String email = authentication.getName();
        return userRepository.findByEmail(email).orElseThrow().getId();
    }

    @PostMapping
    @PreAuthorize("hasRole('STUDENT')")
    public ResponseEntity<ApiResponse<BusPassResponse>> applyForPass(
            @Valid @RequestBody BusPassRequest request, Authentication authentication) {
        Long studentId = getCurrentUserId(authentication);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Pass application submitted successfully",
                        busPassService.applyForPass(studentId, request)));
    }

    @GetMapping("/my")
    @PreAuthorize("hasAnyRole('STUDENT', 'ADMIN')")
    public ResponseEntity<ApiResponse<List<BusPassResponse>>> getMyPasses(Authentication authentication) {
        Long studentId = getCurrentUserId(authentication);
        return ResponseEntity.ok(ApiResponse.success("Passes retrieved",
                busPassService.getStudentPasses(studentId)));
    }

    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<List<BusPassResponse>>> getAllPasses() {
        return ResponseEntity.ok(ApiResponse.success("All passes retrieved", busPassService.getAllPasses()));
    }

    @GetMapping("/status/{status}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<List<BusPassResponse>>> getPassesByStatus(@PathVariable String status) {
        return ResponseEntity.ok(ApiResponse.success("Passes retrieved",
                busPassService.getPassesByStatus(status)));
    }

    @PatchMapping("/{id}/status")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<BusPassResponse>> updatePassStatus(
            @PathVariable Long id, @Valid @RequestBody PassStatusUpdateRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Pass status updated",
                busPassService.updatePassStatus(id, request)));
    }

    @PatchMapping("/{id}/cancel")
    @PreAuthorize("hasAnyRole('STUDENT', 'ADMIN')")
    public ResponseEntity<ApiResponse<BusPassResponse>> cancelPass(
            @PathVariable Long id, Authentication authentication) {
        Long studentId = getCurrentUserId(authentication);
        return ResponseEntity.ok(ApiResponse.success("Pass cancelled",
                busPassService.cancelPass(id, studentId)));
    }
}
