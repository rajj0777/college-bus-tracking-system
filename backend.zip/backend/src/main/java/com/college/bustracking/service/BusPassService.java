package com.college.bustracking.service;

import com.college.bustracking.dto.BusTrackingDTOs.*;
import com.college.bustracking.exception.BusinessException;
import com.college.bustracking.exception.ResourceNotFoundException;
import com.college.bustracking.model.BusPass;
import com.college.bustracking.model.Route;
import com.college.bustracking.model.User;
import com.college.bustracking.repository.BusPassRepository;
import com.college.bustracking.repository.RouteRepository;
import com.college.bustracking.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class BusPassService {

    private final BusPassRepository busPassRepository;
    private final UserRepository userRepository;
    private final RouteRepository routeRepository;
    private final RouteService routeService;
    private final PaymentService paymentService;  // injected for signature verification

    /**
     * Apply for a bus pass.
     *
     * Payment flow enforced here:
     *  1. Student must have already created a Razorpay order (POST /api/payments/create-order)
     *  2. Student completes payment in frontend Razorpay modal
     *  3. Student calls this endpoint with orderId + paymentId + signature
     *  4. Backend verifies signature — if invalid, throws 400
     *  5. Pass is created with paymentStatus=SUCCESS and status=PENDING (awaiting admin approval)
     */
    public BusPassResponse applyForPass(Long studentId, BusPassRequest request) {
        User student = userRepository.findById(studentId)
                .orElseThrow(() -> new ResourceNotFoundException("Student", "id", studentId));

        Route route = routeRepository.findById(request.getRouteId())
                .orElseThrow(() -> new ResourceNotFoundException("Route", "id", request.getRouteId()));

        Optional<BusPass> existingActivePass =
                busPassRepository.findByStudentIdAndStatus(studentId, BusPass.PassStatus.ACTIVE);

        if (existingActivePass.isPresent()) {
            throw new BusinessException("You already have an active bus pass. Please cancel it before applying for a new one.");
        }

        // ── Razorpay payment verification ─────────────────────────────────────
        // Verifies HMAC-SHA256 signature to ensure payment actually happened.
        // Will throw BusinessException if signature is invalid.
        paymentService.verifyAndAssert(
                request.getRazorpayOrderId(),
                request.getRazorpayPaymentId(),
                request.getRazorpaySignature()
        );
        log.info("Payment verified for student {} order {}", studentId, request.getRazorpayOrderId());
        // ─────────────────────────────────────────────────────────────────────

        BusPass pass = BusPass.builder()
                .passNumber(generatePassNumber())
                .student(student)
                .route(route)
                .validFrom(request.getValidFrom())
                .validTo(request.getValidTo())
                .status(BusPass.PassStatus.PENDING)
                .amountPaid(request.getAmountPaid())
                .razorpayOrderId(request.getRazorpayOrderId())
                .razorpayPaymentId(request.getRazorpayPaymentId())
                .razorpaySignature(request.getRazorpaySignature())
                .paymentStatus("SUCCESS")
                .boardingStop(request.getBoardingStop())
                .build();

        return mapToResponse(busPassRepository.save(pass));
    }

    public List<BusPassResponse> getStudentPasses(Long studentId) {
        return busPassRepository.findByStudentIdOrderByCreatedAtDesc(studentId).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    public List<BusPassResponse> getAllPasses() {
        return busPassRepository.findAll().stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    public List<BusPassResponse> getPassesByStatus(String status) {
        BusPass.PassStatus passStatus = BusPass.PassStatus.valueOf(status.toUpperCase());
        return busPassRepository.findByStatus(passStatus).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    public BusPassResponse updatePassStatus(Long passId, PassStatusUpdateRequest request) {
        BusPass pass = busPassRepository.findById(passId)
                .orElseThrow(() -> new ResourceNotFoundException("BusPass", "id", passId));

        BusPass.PassStatus newStatus = BusPass.PassStatus.valueOf(request.getStatus().toUpperCase());

        if (pass.getStatus() != BusPass.PassStatus.PENDING &&
                (newStatus == BusPass.PassStatus.ACTIVE || newStatus == BusPass.PassStatus.REJECTED)) {
            throw new BusinessException("Can only approve/reject PENDING passes");
        }

        pass.setStatus(newStatus);
        pass.setRemarks(request.getRemarks());

        return mapToResponse(busPassRepository.save(pass));
    }

    public BusPassResponse cancelPass(Long passId, Long studentId) {
        BusPass pass = busPassRepository.findById(passId)
                .orElseThrow(() -> new ResourceNotFoundException("BusPass", "id", passId));

        if (!pass.getStudent().getId().equals(studentId)) {
            throw new BusinessException("You can only cancel your own passes");
        }

        if (pass.getStatus() == BusPass.PassStatus.EXPIRED) {
            throw new BusinessException("Cannot cancel an expired pass");
        }

        pass.setStatus(BusPass.PassStatus.CANCELLED);
        return mapToResponse(busPassRepository.save(pass));
    }

    private String generatePassNumber() {
        String year = String.valueOf(LocalDateTime.now().getYear());
        long count = busPassRepository.count() + 1;
        return String.format("PASS-%s-%05d", year, count);
    }

    private BusPassResponse mapToResponse(BusPass pass) {
        UserResponse studentResponse = UserResponse.builder()
                .id(pass.getStudent().getId())
                .name(pass.getStudent().getName())
                .email(pass.getStudent().getEmail())
                .phoneNumber(pass.getStudent().getPhoneNumber())
                .rollNumber(pass.getStudent().getRollNumber())
                .department(pass.getStudent().getDepartment())
                .role(pass.getStudent().getRole().name())
                .build();

        return BusPassResponse.builder()
                .id(pass.getId())
                .passNumber(pass.getPassNumber())
                .student(studentResponse)
                .route(routeService.mapToResponse(pass.getRoute()))
                .validFrom(pass.getValidFrom())
                .validTo(pass.getValidTo())
                .status(pass.getStatus().name())
                .amountPaid(pass.getAmountPaid())
                .boardingStop(pass.getBoardingStop())
                .remarks(pass.getRemarks())
                .razorpayOrderId(pass.getRazorpayOrderId())
                .razorpayPaymentId(pass.getRazorpayPaymentId())
                .paymentStatus(pass.getPaymentStatus())
                .createdAt(pass.getCreatedAt())
                .build();
    }
}
