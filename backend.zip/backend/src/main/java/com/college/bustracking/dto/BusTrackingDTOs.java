package com.college.bustracking.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

public class BusTrackingDTOs {

    // =============================================
    // AUTH DTOs
    // =============================================

    @Data @NoArgsConstructor @AllArgsConstructor
    public static class LoginRequest {
        @Email(message = "Please enter a valid email")
        @NotBlank(message = "Email is required")
        private String email;

        @NotBlank(message = "Password is required")
        private String password;
    }

    @Data @NoArgsConstructor @AllArgsConstructor @Builder
    public static class AuthResponse {
        private String token;
        private String tokenType = "Bearer";
        private Long userId;
        private String name;
        private String email;
        private String role;
    }

    @Data @NoArgsConstructor @AllArgsConstructor
    public static class RegisterRequest {
        @NotBlank(message = "Name is required")
        private String name;

        @Email(message = "Please enter a valid email")
        @NotBlank(message = "Email is required")
        private String email;

        @NotBlank(message = "Password is required")
        private String password;

        private String phoneNumber;
        private String rollNumber;
        private String department;
        private String role = "STUDENT";
    }

    // =============================================
    // USER DTOs
    // =============================================

    @Data @NoArgsConstructor @AllArgsConstructor @Builder
    public static class UserResponse {
        private Long id;
        private String name;
        private String email;
        private String phoneNumber;
        private String role;
        private String rollNumber;
        private String department;
        private Boolean isActive;
        private LocalDateTime createdAt;
    }

    // =============================================
    // BUS DTOs
    // =============================================

    @Data @NoArgsConstructor @AllArgsConstructor
    public static class BusRequest {
        @NotBlank(message = "Bus number is required")
        private String busNumber;

        @NotBlank(message = "Driver name is required")
        private String driverName;

        private String driverPhone;
        private Integer capacity;
        private String status;
    }

    @Data @NoArgsConstructor @AllArgsConstructor @Builder
    public static class BusResponse {
        private Long id;
        private String busNumber;
        private String driverName;
        private String driverPhone;
        private Integer capacity;
        private String status;
        private Double currentLatitude;
        private Double currentLongitude;
        private String currentLocationName;
        private LocalDateTime lastLocationUpdate;
    }

    @Data @NoArgsConstructor @AllArgsConstructor
    public static class LocationUpdateRequest {
        @NotNull(message = "Latitude is required")
        private Double latitude;

        @NotNull(message = "Longitude is required")
        private Double longitude;

        private String locationName;
    }

    // =============================================
    // ROUTE DTOs  (with Google Maps coordinates)
    // =============================================

    @Data @NoArgsConstructor @AllArgsConstructor
    public static class RouteRequest {
        @NotBlank(message = "Route name is required")
        private String routeName;

        @NotBlank(message = "Route number is required")
        private String routeNumber;

        // Human-readable place name (from Google Maps reverse geocode or typed)
        private String startPoint;
        // Latitude/Longitude picked from Google Maps for start point
        private Double startLatitude;
        private Double startLongitude;

        // Human-readable place name for end point
        private String endPoint;
        // Latitude/Longitude picked from Google Maps for end point
        private Double endLatitude;
        private Double endLongitude;

        private LocalTime departureTime;
        private LocalTime returnTime;
        private Double totalDistanceKm;

        // Comma-separated stop names (e.g. "City Center, MG Road, Silk Board")
        private String stops;

        // JSON string of stop coordinates for Google Maps rendering:
        // [{"name":"City Center","lat":12.97,"lng":77.59}, ...]
        // Frontend sends this after user picks stops on the map
        private String stopsCoordinates;

        private Double monthlyFee;
        private Long busId;
    }

    @Data @NoArgsConstructor @AllArgsConstructor @Builder
    public static class RouteResponse {
        private Long id;
        private String routeName;
        private String routeNumber;
        private String startPoint;
        private Double startLatitude;
        private Double startLongitude;
        private String endPoint;
        private Double endLatitude;
        private Double endLongitude;
        private LocalTime departureTime;
        private LocalTime returnTime;
        private Double totalDistanceKm;
        private String stops;
        private String stopsCoordinates;
        private Double monthlyFee;
        private Boolean isActive;
        private BusResponse bus;
    }

    // =============================================
    // BUS PASS DTOs  (with Razorpay fields)
    // =============================================

    @Data @NoArgsConstructor @AllArgsConstructor
    public static class BusPassRequest {
        @NotNull(message = "Route ID is required")
        private Long routeId;

        @NotNull(message = "Valid from date is required")
        private LocalDate validFrom;

        @NotNull(message = "Valid to date is required")
        private LocalDate validTo;

        private String boardingStop;

        // Razorpay order ID — obtained from POST /api/payments/create-order
        // Must be provided before applying for a pass
        @NotBlank(message = "Razorpay order ID is required. Call /api/payments/create-order first.")
        private String razorpayOrderId;

        // Razorpay payment ID — returned by Razorpay SDK on frontend after payment
        @NotBlank(message = "Razorpay payment ID is required")
        private String razorpayPaymentId;

        // Razorpay signature — returned by Razorpay SDK on frontend after payment
        @NotBlank(message = "Razorpay signature is required")
        private String razorpaySignature;

        private Double amountPaid;
    }

    @Data @NoArgsConstructor @AllArgsConstructor @Builder
    public static class BusPassResponse {
        private Long id;
        private String passNumber;
        private UserResponse student;
        private RouteResponse route;
        private LocalDate validFrom;
        private LocalDate validTo;
        private String status;
        private Double amountPaid;
        private String boardingStop;
        private String remarks;
        private String razorpayOrderId;
        private String razorpayPaymentId;
        private String paymentStatus;
        private LocalDateTime createdAt;
    }

    @Data @NoArgsConstructor @AllArgsConstructor
    public static class PassStatusUpdateRequest {
        @NotBlank(message = "Status is required")
        private String status;

        private String remarks;
    }

    // =============================================
    // RAZORPAY DTOs
    // =============================================

    /**
     * Request to create a Razorpay order before applying for a pass.
     * amount is in INR (will be converted to paise internally).
     */
    @Data @NoArgsConstructor @AllArgsConstructor
    public static class PaymentOrderRequest {
        @NotNull(message = "Amount is required")
        private Double amount;       // in INR e.g. 500.00

        // Optional: receipt label e.g. "pass-student-2-route-1"
        private String receipt;
    }

    /**
     * Response returned to frontend after creating a Razorpay order.
     * Frontend passes this to Razorpay JS SDK to open the payment modal.
     */
    @Data @NoArgsConstructor @AllArgsConstructor @Builder
    public static class PaymentOrderResponse {
        private String orderId;       // Razorpay order ID (rzp_test_...)
        private Double amount;        // Amount in INR
        private String currency;      // "INR"
        private String keyId;         // Razorpay Key ID — safe to expose to frontend
        private String receipt;
    }

    /**
     * Request to verify Razorpay payment signature.
     * Frontend sends this after the payment modal closes successfully.
     */
    @Data @NoArgsConstructor @AllArgsConstructor
    public static class PaymentVerifyRequest {
        @NotBlank(message = "Order ID is required")
        private String razorpayOrderId;

        @NotBlank(message = "Payment ID is required")
        private String razorpayPaymentId;

        @NotBlank(message = "Signature is required")
        private String razorpaySignature;
    }

    /**
     * Result of signature verification.
     */
    @Data @NoArgsConstructor @AllArgsConstructor @Builder
    public static class PaymentVerifyResponse {
        private boolean verified;
        private String message;
    }

    // =============================================
    // GENERIC RESPONSE WRAPPER
    // =============================================

    @Data @NoArgsConstructor @AllArgsConstructor @Builder
    public static class ApiResponse<T> {
        private boolean success;
        private String message;
        private T data;

        public static <T> ApiResponse<T> success(String message, T data) {
            return ApiResponse.<T>builder()
                    .success(true)
                    .message(message)
                    .data(data)
                    .build();
        }

        public static <T> ApiResponse<T> error(String message) {
            return ApiResponse.<T>builder()
                    .success(false)
                    .message(message)
                    .build();
        }
    }
}
