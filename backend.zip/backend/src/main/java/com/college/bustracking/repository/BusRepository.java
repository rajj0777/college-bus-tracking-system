package com.college.bustracking.repository;

import com.college.bustracking.model.Bus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface BusRepository extends JpaRepository<Bus, Long> {

    Optional<Bus> findByBusNumber(String busNumber);

    Boolean existsByBusNumber(String busNumber);

    List<Bus> findByStatus(Bus.BusStatus status);

    @Modifying
    @Transactional
    @Query("UPDATE Bus b SET b.currentLatitude = :lat, b.currentLongitude = :lng, " +
           "b.currentLocationName = :locationName, b.lastLocationUpdate = :updateTime " +
           "WHERE b.id = :busId")
    int updateBusLocation(@Param("busId") Long busId,
                          @Param("lat") Double latitude,
                          @Param("lng") Double longitude,
                          @Param("locationName") String locationName,
                          @Param("updateTime") LocalDateTime updateTime);
}
