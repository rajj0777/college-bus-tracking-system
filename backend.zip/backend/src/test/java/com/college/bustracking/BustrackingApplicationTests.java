package com.college.bustracking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BustrackingApplicationTests {

	@Test
	void contextLoads() {
	}

}
